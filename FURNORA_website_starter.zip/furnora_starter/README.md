# FURNORA website starter

This package turns the FURNORA prototype into a responsive front-end starter and a separate backend/database scaffold.

## Included
- Bright-grey, white, charcoal and bronze design system.
- Home, Shop, Discover, Brands, Following, brand profile, product detail, cart, and admin-demo views.
- Product/brand/category search and filters.
- Follow/unfollow brands, public follower/following counts, public brand-following lists, and profile navigation.
- Vendor-controlled display of contact details in the data model.
- Manual badge and featured-product controls shown as a **front-end-only demonstration**.
- Local demo state for follows, saved products and cart.
- PostgreSQL schema for users, brands, customer-to-brand follows, brand-to-brand follows, vendor applications, products, orders and audit logs.
- Express API starter and Paystack integration safety notes.

## Run the front-end
The simplest option is to open `public/index.html` in a browser. Some browsers restrict local assets; if needed, serve the folder with a local static server. For example, from the project directory:

```bash
python -m http.server 8080 --directory public
```

Then open `http://localhost:8080`.

The Unsplash product/lifestyle images and CDN assets require internet access. Product, vendor, follower, and engagement data are illustrative.

## Run the API scaffold
1. Install a current supported Node.js release and PostgreSQL.
2. Create a PostgreSQL database and run `server/schema.sql`.
3. Copy `server/.env.example` to `server/.env` and fill in local development values.
4. In the `server` directory, run `npm install`, then `npm start`.

The API is deliberately incomplete. Add authentication, password hashing, email verification, role-based authorisation, request validation, rate limiting, file storage, and tests before production.

## Important limitations
- Browser localStorage is only for the demo; it is not shared across devices and is not secure.
- The admin demo is not a real secured admin panel. Anyone with the page can change the local demo badge/featured state.
- Checkout is intentionally disabled. No real payment is taken.
- Never put Paystack secret keys in frontend code. Implement server-side cart price validation, order creation, Paystack initialization and server-side verification, signed webhook processing, idempotency, refunds and reconciliation.
- A marketplace cart with several vendors requires a confirmed provider settlement approach. Validate Paystack split/subaccount and settlement eligibility for the specific marketplace setup before promising automatic multi-vendor payouts.
- The 5.99% commission is represented in the schema as a default rate but must be calculated server-side and clearly disclosed. Fees, taxes, delivery and refunds need explicit rules.
- Vendor delivery is the initial planned approach. Add delivery estimates, vendor policies and order tracking before launch.
- Social handles submitted during vendor applications must be validated and opened safely. Verify the business manually; follower count alone is not proof of legitimacy.
- Ensure vendors have rights to all product images/content and use properly licensed fonts, icons and imagery.
- Replace all demo brand names, metrics, prices, descriptions and example links before publishing.

## Planned production steps
1. Finalise UX and policies.
2. Implement account authentication and customer/vendor/admin roles.
3. Build public vendor applications and secure email invitations.
4. Implement admin review notes, decisions and audit logs.
5. Add vendor dashboard, products, inventory, images and policies.
6. Implement persistent follow/unfollow and accurate server-generated counts.
7. Implement manual badge and product-feature workflows with admin-only authorisation.
8. Implement and test secure Paystack payment and settlement flow.
9. Add order history, refunds, notifications, monitoring, accessibility review and deployment.
