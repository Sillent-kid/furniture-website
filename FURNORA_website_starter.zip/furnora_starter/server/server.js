import express from "express";
import helmet from "helmet";
import cors from "cors";
import dotenv from "dotenv";
import pg from "pg";
import crypto from "node:crypto";

dotenv.config();
const app = express();
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
app.use(helmet());
app.use(cors({ origin: process.env.FRONTEND_ORIGIN || "http://localhost:8080" }));
app.use(express.json({ limit: "200kb" }));

app.get("/api/health", (_req,res) => res.json({ ok:true, service:"FURNORA API starter" }));
app.get("/api/brands", async (req,res,next) => {
  try {
    const q = String(req.query.q || "").slice(0,100);
    const { rows } = await pool.query(
      `SELECT b.id,b.name,b.slug,b.description,b.city,b.state,b.categories,b.verified_badge,
       (SELECT count(*)::int FROM user_brand_follows f WHERE f.brand_id=b.id) AS customer_followers,
       (SELECT count(*)::int FROM brand_follows f WHERE f.followed_brand_id=b.id) AS brand_followers,
       (SELECT count(*)::int FROM brand_follows f WHERE f.follower_brand_id=b.id) AS following_count
       FROM brands b WHERE b.application_status='approved' AND (b.name ILIKE $1 OR b.description ILIKE $1)
       ORDER BY b.created_at DESC LIMIT 100`, [`%${q}%`]);
    res.json({ data: rows });
  } catch(e){ next(e); }
});

// Authentication and role middleware must be added before exposing any write/admin endpoints.
// Do not expose vendor approval, badge awards, product promotion, or payment actions without it.
// The starter intentionally does not implement fake insecure login or admin endpoints.

app.post("/api/payments/initialize", async (req,res) => {
  // TODO: require authenticated customer; validate cart/product prices against PostgreSQL;
  // create a pending order; compute 5.99% commission server-side; do not trust browser totals.
  // For a multi-vendor cart, configure and verify Paystack's supported settlement model first.
  if (!process.env.PAYSTACK_SECRET_KEY) return res.status(503).json({ error:"Payments are not configured." });
  return res.status(501).json({ error:"Payment initialization is intentionally not enabled in this starter. Complete order validation, vendor settlement configuration, and idempotency before enabling it." });
});

app.post("/api/payments/webhook", express.raw({type:"application/json"}), (req,res) => {
  // In production, mount a dedicated raw-body webhook route before express.json().
  // Verify x-paystack-signature with HMAC-SHA512 using the secret key, then verify payment
  // status/reference server-side and process idempotently. Never trust a browser redirect.
  const secret = process.env.PAYSTACK_SECRET_KEY;
  const signature = req.headers["x-paystack-signature"];
  if (!secret || !signature || !Buffer.isBuffer(req.body)) return res.sendStatus(400);
  const expected = crypto.createHmac("sha512", secret).update(req.body).digest("hex");
  const a=Buffer.from(String(signature)); const b=Buffer.from(expected);
  if(a.length!==b.length || !crypto.timingSafeEqual(a,b)) return res.sendStatus(401);
  // TODO: parse payload and verify/process successful charge using idempotent DB transaction.
  return res.sendStatus(200);
});

app.use((err,_req,res,_next)=>{ console.error(err); res.status(500).json({error:"Internal server error"}); });
const port = Number(process.env.PORT || 4242);
app.listen(port, ()=>console.log(`FURNORA API starter listening on ${port}`));
