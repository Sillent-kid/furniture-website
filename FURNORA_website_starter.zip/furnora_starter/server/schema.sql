-- PostgreSQL starter schema. Run only after creating a database and reviewing the design.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','vendor','admin')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE brands (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_user_id UUID REFERENCES users(id),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  business_type TEXT,
  established_year INTEGER,
  city TEXT,
  state TEXT,
  country TEXT DEFAULT 'Nigeria',
  categories TEXT[] NOT NULL DEFAULT '{}',
  website_url TEXT,
  email_public BOOLEAN NOT NULL DEFAULT false,
  phone_public BOOLEAN NOT NULL DEFAULT false,
  whatsapp_public BOOLEAN NOT NULL DEFAULT false,
  website_public BOOLEAN NOT NULL DEFAULT false,
  social_links JSONB NOT NULL DEFAULT '{}',
  public_contact JSONB NOT NULL DEFAULT '{}',
  application_status TEXT NOT NULL DEFAULT 'pending' CHECK (application_status IN ('pending','approved','rejected','suspended')),
  verified_badge BOOLEAN NOT NULL DEFAULT false,
  verified_by UUID REFERENCES users(id),
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE brand_follows (
  follower_brand_id UUID NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  followed_brand_id UUID NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (follower_brand_id, followed_brand_id),
  CHECK (follower_brand_id <> followed_brand_id)
);

CREATE TABLE user_brand_follows (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  brand_id UUID NOT NULL REFERENCES brands(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, brand_id)
);

CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_id UUID NOT NULL REFERENCES brands(id),
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  description TEXT NOT NULL,
  category TEXT NOT NULL,
  price_kobo BIGINT NOT NULL CHECK (price_kobo >= 0),
  currency CHAR(3) NOT NULL DEFAULT 'NGN',
  image_urls JSONB NOT NULL DEFAULT '[]',
  dimensions JSONB NOT NULL DEFAULT '{}',
  materials TEXT,
  inventory_quantity INTEGER,
  status TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','published','hidden','out_of_stock')),
  featured BOOLEAN NOT NULL DEFAULT false,
  featured_until TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE product_saves (
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, product_id)
);

CREATE TABLE vendor_applications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  brand_name TEXT NOT NULL,
  applicant_name TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT,
  business_address TEXT,
  website_url TEXT,
  social_links JSONB NOT NULL DEFAULT '{}',
  categories TEXT[] NOT NULL DEFAULT '{}',
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','approved','rejected','more_info','revoked')),
  admin_notes TEXT,
  reviewed_by UUID REFERENCES users(id),
  reviewed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_user_id UUID NOT NULL REFERENCES users(id),
  order_number TEXT NOT NULL UNIQUE,
  currency CHAR(3) NOT NULL DEFAULT 'NGN',
  subtotal_kobo BIGINT NOT NULL CHECK (subtotal_kobo >= 0),
  commission_rate NUMERIC(5,4) NOT NULL DEFAULT 0.0599,
  commission_kobo BIGINT NOT NULL CHECK (commission_kobo >= 0),
  status TEXT NOT NULL DEFAULT 'pending_payment' CHECK (status IN ('pending_payment','paid','processing','shipped','completed','cancelled','refunded')),
  paystack_reference TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id),
  brand_id UUID NOT NULL REFERENCES brands(id),
  quantity INTEGER NOT NULL CHECK (quantity > 0),
  unit_price_kobo BIGINT NOT NULL CHECK (unit_price_kobo >= 0),
  vendor_amount_kobo BIGINT NOT NULL CHECK (vendor_amount_kobo >= 0)
);

CREATE TABLE admin_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_user_id UUID NOT NULL REFERENCES users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID NOT NULL,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Do not expose this schema directly to browsers. Enforce authorisation in the API.
-- Brand follower counts should be calculated from the follow tables or maintained transactionally.
-- Admin badge / product-feature changes must be audited by the server.
